<?php

require_once('simplepie-1.8.0/autoloader.php');
error_reporting(0);

$conn = new mysqli('localhost','root','','oaw','33065');

if(!$conn){
    echo "No se pudo realizar la conexión PHP - MySQL";
}

if (isset($_GET['urls'])) {
    $sql = "DELETE FROM feeds;";
    $conn->query($sql);
    $urls = $_GET['urls'];
    $html = "";
    foreach ($urls as $feedUrl) {
        $feed = new SimplePie();
        $feed->set_feed_url($feedUrl);
        $feed->enable_cache(false);
        $feed->strip_attributes(array('img'));
        $feed->init();
        $feed->handle_content_type();
       
        foreach ($feed->get_items() as $item) {
            
            if($item != null && !empty($item->get_date()) && !empty($item->get_title()) && !empty($item->get_description()) && !empty($item->get_categories())){
                $html .= '<tr>'; 
                $html .= '<td>' . $item->get_date('j-F-Y g:i a') . '</td>';
                $html .= '<td>' . $item->get_title() . '</td>';
                $html .= '<td><a href="' . $item->get_permalink() . '"> '. $item->get_permalink() .'</td>';
                $html .= '<td>' . $item->get_description() . '</td>';
                //categories
                //$html .= '<td>';
                $categories = $item->get_categories();
                usort($categories, function($a, $b) {
                    return strcasecmp($a->get_label(), $b->get_label());
                });

                $html .= '<td>';
                foreach ($categories as $category) {
                    $html .= "<p>" . $category->get_label() . "<p>";
                }
                $html .= '</td>';
                $html .= '</tr>';

                $date = $conn->real_escape_string($item->get_date('Y-m-d H:i:s'));
                $title = $conn->real_escape_string($item->get_title());
                $permalink = $conn->real_escape_string($item->get_permalink());
                $description = $conn->real_escape_string($item->get_description());
                $categories = $item->get_categories();
                $category_labels = array();
                foreach ($categories as $category) {
                    $category_labels[] = $conn->real_escape_string($category->get_label());
                }
                $categoriesJson = json_encode($categoryLabels);
                $sql_insert = "INSERT INTO feeds (`id`, `fecha`, `titulo`, `url`, `descripcion`, `categorias`) VALUES (DEFAULT,'$date', '$title', '$permalink', '$description', '$categoriesJson')";
                $conn->query($sql_insert);

            }else{
                $html .= '<tr>';
                //echo 'El url '. $feedUrl .' no tiene todas los campos de la tabla';
                if($item->get_date() != null){
                    $html .= '<td>' . $item->get_date('j-F-Y g:i a') . '</td>';
                }else{
                    $html .= '<td>' . " " . '</td>';
                }
                if($item->get_title() != null){
                    $html .= '<td>' . $item->get_title() . '</td>';
                }else{
                    $html .= '<td>' . " " . '</td>';
                }
                if($item->get_permalink() != null){
                    $html .= '<td><a href="' . $item->get_permalink() . '"> '. $item->get_permalink() .'</td>';
                }else{
                    $html .= '<td>' . " " . '</td>';
                }
                if($item->get_description()!=null){
                    $html .= '<td>' . $item->get_description() . '</td>';
                }else{
                    $html .= '<td>' . " " . '</td>';
                }
                if($item->get_categories()!=null){
                    $categories = $item->get_categories();
                    usort($categories, function($a, $b) {
                        return strcasecmp($a->get_label(), $b->get_label());
                    });

                    $html .= '<td>';
                    foreach ($categories as $category) {
                        $html .= "<p>" . $category->get_label() . "<p>";
                    }
                    $html .= '</td>';
                }else{
                    $html .= '<td>' . " " . '</td>';
                }

                $date = $conn->real_escape_string($item->get_date('Y-m-d H:i:s'));
                $title = $conn->real_escape_string($item->get_title());
                $permalink = $conn->real_escape_string($item->get_permalink());
                $description = $conn->real_escape_string($item->get_description());
                $categories = $item->get_categories();
                $category_labels = array();
                foreach ($categories as $category) {
                    $category_labels[] = $conn->real_escape_string($category->get_label());
                }
                $categoriesJson = json_encode($categoryLabels);

                $sql_insert = "INSERT INTO feeds (`id`, `fecha`, `titulo`, `url`, `descripcion`, `categorias`) VALUES (DEFAULT,'$date', '$title', '$permalink', '$description', '$categoriesJson')";
                $conn->query($sql_insert);
            }
        }
    }
    echo $html;
    $conn->close();
} else {
    echo "No se proporcionó la URL del feed.";
    $conn->close();

}
