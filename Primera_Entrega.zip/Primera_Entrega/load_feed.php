<?php
$conn = new mysqli('localhost','root','','oaw','33065');

if(!$conn){
    echo "No se pudo realizar la conexión PHP - MySQL";
}
$sql = "SELECT fecha, titulo, url, descripcion, categorias FROM feeds order by fecha desc";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['fecha'] . "</td>";
        echo "<td>" . $row['titulo'] . "</td>";
        echo "<td><a href='" . $row['url'] . "'>" . $row['url'] . "</a></td>";
        echo "<td>" . $row['descripcion'] . "</td>";
        $categorias = json_decode($row['categorias']);
        echo "<td>";
        if($categorias!=null){
            foreach ($categorias as $categoria) {
                echo "<p>" . $categoria . "</p>";
            }
        }else{
            echo "<p> </p>";
        }
        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "0 resultados";
}
$conn->close();

